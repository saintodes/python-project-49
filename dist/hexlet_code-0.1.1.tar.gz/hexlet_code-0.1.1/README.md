### Hexlet tests and linter status:
[![Actions Status](https://github.com/saintodes/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/saintodes/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/de07472ab4190224e3b7/maintainability)](https://codeclimate.com/github/saintodes/python-project-49/maintainability)
	
[![asciicast](https://asciinema.org/a/iVfI187lUAVj3VMK4VhTbu6ol.svg)](https://asciinema.org/a/iVfI187lUAVj3VMK4VhTbu6ol)
[![asciicast](https://asciinema.org/a/7ZNm8fJ9TcZT3CTpPZ8fFXBow.svg)](https://asciinema.org/a/7ZNm8fJ9TcZT3CTpPZ8fFXBow)
[![asciicast](https://asciinema.org/a/0sweiwjEZm1C5UBtTRZ1QfzGc.svg)](https://asciinema.org/a/0sweiwjEZm1C5UBtTRZ1QfzGc)
[![asciicast](https://asciinema.org/a/kssDjb8ktIPaKrAfC9uSfMDlq.svg)](https://asciinema.org/a/kssDjb8ktIPaKrAfC9uSfMDlq)
brain prime:[![asciicast](https://asciinema.org/a/ixKouL8Mxg4Qv3b6ZMBAJz1vQ.svg)](https://asciinema.org/a/ixKouL8Mxg4Qv3b6ZMBAJz1vQ)
